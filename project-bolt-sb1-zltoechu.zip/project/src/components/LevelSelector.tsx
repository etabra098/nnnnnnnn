import React, { useEffect, useState } from 'react';
import { ChevronLeft, Lock, Trophy } from 'lucide-react';
import { GameScreen } from '../App';
import Button from './ui/Button';
import { useGameState } from '../contexts/GameContext';
import { getLevelTheme } from '../utils/levelUtils';

interface LevelSelectorProps {
  navigateTo: (screen: GameScreen) => void;
  startLevel: (level: number) => void;
}

const LevelSelector: React.FC<LevelSelectorProps> = ({ navigateTo, startLevel }) => {
  const { completedLevels } = useGameState();
  const [selectedSection, setSelectedSection] = useState<'basic' | 'animal' | 'vehicle'>('basic');

  const sections = [
    { id: 'basic', name: 'Basic Shapes', levels: [1, 2, 3, 4, 5] },
    { id: 'animal', name: 'Animal Shapes', levels: [6, 7, 8, 9, 10] },
    { id: 'vehicle', name: 'Vehicle Shapes', levels: [11, 12, 13, 14, 15] },
  ];

  const isLevelUnlocked = (level: number) => {
    if (level === 1) return true;
    return completedLevels.includes(level - 1);
  };

  return (
    <div className="p-6">
      <div className="flex items-center mb-6">
        <Button
          onClick={() => navigateTo('home')}
          variant="outline"
          size="sm"
          icon={<ChevronLeft size={18} />}
        >
          Back
        </Button>
        <h1 className="text-2xl font-bold text-center flex-1">Select a Level</h1>
      </div>

      <div className="flex mb-6 gap-2 border-b pb-4">
        {sections.map((section) => (
          <button
            key={section.id}
            onClick={() => setSelectedSection(section.id as any)}
            className={`flex-1 py-2 px-3 rounded-lg font-medium text-sm md:text-base transition-colors ${
              selectedSection === section.id
                ? 'bg-purple-100 text-purple-700'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            {section.name}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {sections
          .find((s) => s.id === selectedSection)
          ?.levels.map((level) => {
            const isUnlocked = isLevelUnlocked(level);
            const isCompleted = completedLevels.includes(level);
            const theme = getLevelTheme(level);
            
            return (
              <button
                key={level}
                onClick={() => isUnlocked && startLevel(level)}
                disabled={!isUnlocked}
                className={`aspect-square rounded-xl p-4 flex flex-col items-center justify-center gap-2 transition-all ${
                  isUnlocked
                    ? `bg-${theme.color}-100 hover:bg-${theme.color}-200 border-2 border-${theme.color}-300 cursor-pointer`
                    : 'bg-gray-100 border-2 border-gray-200 cursor-not-allowed'
                }`}
              >
                <div className="text-xl font-bold">{level}</div>
                <div className="text-sm">{theme.name}</div>
                {!isUnlocked && <Lock size={18} className="text-gray-400 mt-1" />}
                {isCompleted && <Trophy size={18} className="text-yellow-500 mt-1" />}
              </button>
            );
          })}
      </div>
    </div>
  );
};

export default LevelSelector;