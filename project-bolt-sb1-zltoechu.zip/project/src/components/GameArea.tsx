import React, { useEffect, useState, useRef } from 'react';
import { ChevronLeft, RefreshCw, Home } from 'lucide-react';
import { GameScreen } from '../App';
import Button from './ui/Button';
import { useGameState } from '../contexts/GameContext';
import { useDragAndDrop } from '../hooks/useDragAndDrop';
import { getLevelData } from '../data/levels';
import ShapeItem from './ShapeItem';
import DropZone from './DropZone';
import ProgressBar from './ui/ProgressBar';
import LevelComplete from './LevelComplete';
import { Shape } from '../types';
import { useAudio } from '../contexts/AudioContext';

interface GameAreaProps {
  level: number;
  navigateTo: (screen: GameScreen) => void;
}

const GameArea: React.FC<GameAreaProps> = ({ level, navigateTo }) => {
  const { completeLevel } = useGameState();
  const [levelData, setLevelData] = useState(getLevelData(level));
  const [shuffledShapes, setShuffledShapes] = useState<Shape[]>([]);
  const [matchedShapes, setMatchedShapes] = useState<string[]>([]);
  const [showLevelComplete, setShowLevelComplete] = useState(false);
  const { playMatchSound, playErrorSound, playLevelCompleteSound } = useAudio();
  const gameAreaRef = useRef<HTMLDivElement>(null);
  
  const {
    handleDragStart,
    handleDragEnd,
    handleDrop,
    activeShape,
  } = useDragAndDrop({
    onCorrectMatch: (shapeId) => {
      setMatchedShapes((prev) => [...prev, shapeId]);
      playMatchSound();
    },
    onIncorrectMatch: () => {
      playErrorSound();
    }
  });

  useEffect(() => {
    // Shuffle shapes at the beginning of the level
    const shapes = [...levelData.shapes];
    for (let i = shapes.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shapes[i], shapes[j]] = [shapes[j], shapes[i]];
    }
    setShuffledShapes(shapes);
    setMatchedShapes([]);
  }, [level, levelData.shapes]);

  useEffect(() => {
    // Check if level is complete
    if (matchedShapes.length > 0 && matchedShapes.length === levelData.shapes.length) {
      setTimeout(() => {
        playLevelCompleteSound();
        completeLevel(level);
        setShowLevelComplete(true);
      }, 500);
    }
  }, [matchedShapes, levelData.shapes.length, level, completeLevel, playLevelCompleteSound]);

  const resetLevel = () => {
    setMatchedShapes([]);
    // Reshuffle shapes
    const shapes = [...levelData.shapes];
    for (let i = shapes.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shapes[i], shapes[j]] = [shapes[j], shapes[i]];
    }
    setShuffledShapes(shapes);
  };

  return (
    <div className="flex flex-col h-full min-h-[600px]" ref={gameAreaRef}>
      <div className="bg-white p-4 border-b border-gray-200 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button
            onClick={() => navigateTo('levels')}
            variant="outline"
            size="sm"
            icon={<ChevronLeft size={18} />}
          >
            Back
          </Button>
          <h1 className="text-xl font-bold">Level {level}: {levelData.title}</h1>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={resetLevel}
            variant="outline"
            size="sm"
            icon={<RefreshCw size={18} />}
          >
            Reset
          </Button>
          <Button
            onClick={() => navigateTo('home')}
            variant="outline"
            size="sm"
            icon={<Home size={18} />}
          />
        </div>
      </div>
      
      <div className="p-4">
        <ProgressBar 
          current={matchedShapes.length} 
          total={levelData.shapes.length} 
        />
      </div>
      
      <div className="flex-1 flex flex-col md:flex-row gap-8 p-4">
        <div className="flex-1 bg-blue-50 rounded-xl p-4 flex flex-wrap gap-4 justify-center items-center">
          {shuffledShapes.map((shape) => (
            !matchedShapes.includes(shape.id) && (
              <ShapeItem
                key={shape.id}
                shape={shape}
                onDragStart={handleDragStart}
                onDragEnd={handleDragEnd}
                isActive={activeShape?.id === shape.id}
              />
            )
          ))}
        </div>
        
        <div className="flex-1 bg-purple-50 rounded-xl p-4 flex flex-wrap gap-4 justify-center items-center">
          {levelData.shapes.map((shape) => (
            <DropZone
              key={shape.id}
              shape={shape}
              onDrop={handleDrop}
              isMatched={matchedShapes.includes(shape.id)}
            />
          ))}
        </div>
      </div>
      
      {showLevelComplete && (
        <LevelComplete
          level={level}
          onNext={() => {
            setShowLevelComplete(false);
            if (level < 15) {
              const nextLevel = level + 1;
              setLevelData(getLevelData(nextLevel));
              navigateTo('game');
            } else {
              navigateTo('levels');
            }
          }}
          onMenu={() => {
            setShowLevelComplete(false);
            navigateTo('levels');
          }}
        />
      )}
    </div>
  );
};

export default GameArea;