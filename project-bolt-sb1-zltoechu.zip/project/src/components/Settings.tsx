import React, { useState } from 'react';
import { ChevronLeft, Volume2, VolumeX, SunMoon, Sliders } from 'lucide-react';
import { GameScreen } from '../App';
import Button from './ui/Button';
import { useAudio } from '../contexts/AudioContext';
import { useGameState } from '../contexts/GameContext';

interface SettingsProps {
  navigateTo: (screen: GameScreen) => void;
}

const Settings: React.FC<SettingsProps> = ({ navigateTo }) => {
  const { volume, setVolume, isMuted, toggleMute } = useAudio();
  const { 
    highContrastMode, 
    toggleHighContrastMode,
    gameSpeed,
    setGameSpeed,
    resetProgress
  } = useGameState();
  
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  
  return (
    <div className="p-6 max-w-2xl mx-auto">
      <div className="flex items-center mb-6">
        <Button
          onClick={() => navigateTo('home')}
          variant="outline"
          size="sm"
          icon={<ChevronLeft size={18} />}
        >
          Back
        </Button>
        <h1 className="text-2xl font-bold text-center flex-1">Settings</h1>
      </div>
      
      <div className="space-y-8">
        <div className="bg-gray-50 rounded-xl p-4">
          <h2 className="font-bold text-lg mb-4 flex items-center gap-2">
            <Volume2 size={20} />
            Sound Settings
          </h2>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-700">Volume</span>
              <div className="flex items-center gap-2">
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={volume}
                  onChange={(e) => setVolume(Number(e.target.value))}
                  className="w-40"
                />
                <span className="w-8 text-center">{volume}%</span>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-gray-700">Mute Sounds</span>
              <Button
                onClick={toggleMute}
                variant="outline"
                size="sm"
                icon={isMuted ? <VolumeX size={18} /> : <Volume2 size={18} />}
              >
                {isMuted ? 'Unmute' : 'Mute'}
              </Button>
            </div>
          </div>
        </div>
        
        <div className="bg-gray-50 rounded-xl p-4">
          <h2 className="font-bold text-lg mb-4 flex items-center gap-2">
            <Sliders size={20} />
            Gameplay Settings
          </h2>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-700">Game Speed</span>
              <div className="flex items-center gap-2">
                <span className="text-sm">Slow</span>
                <input
                  type="range"
                  min="0.5"
                  max="2"
                  step="0.1"
                  value={gameSpeed}
                  onChange={(e) => setGameSpeed(Number(e.target.value))}
                  className="w-24"
                />
                <span className="text-sm">Fast</span>
                <span className="w-8 text-center">{gameSpeed}x</span>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-gray-700">High Contrast Mode</span>
              <Button
                onClick={toggleHighContrastMode}
                variant={highContrastMode ? 'primary' : 'outline'}
                size="sm"
                icon={<SunMoon size={18} />}
              >
                {highContrastMode ? 'On' : 'Off'}
              </Button>
            </div>
          </div>
        </div>
        
        <div className="mt-8 border-t pt-6">
          <h2 className="font-bold text-lg mb-4">Game Progress</h2>
          
          {!showResetConfirm ? (
            <Button
              onClick={() => setShowResetConfirm(true)}
              variant="danger"
            >
              Reset All Progress
            </Button>
          ) : (
            <div className="bg-red-50 p-4 rounded-lg">
              <p className="text-red-600 mb-4">Are you sure? This will erase all your progress and cannot be undone.</p>
              <div className="flex gap-2">
                <Button
                  onClick={() => {
                    resetProgress();
                    setShowResetConfirm(false);
                  }}
                  variant="danger"
                >
                  Yes, Reset Everything
                </Button>
                <Button
                  onClick={() => setShowResetConfirm(false)}
                  variant="outline"
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Settings;