import React from 'react';
import { Shape } from '../types';
import { ShapeIcon } from './ShapeIcon';

interface DropZoneProps {
  shape: Shape;
  onDrop: (dropZoneId: string) => void;
  isMatched: boolean;
}

const DropZone: React.FC<DropZoneProps> = ({ shape, onDrop, isMatched }) => {
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (!isMatched) {
      onDrop(shape.id);
    }
  };

  return (
    <div
      className={`w-24 h-24 border-2 rounded-lg flex items-center justify-center transition-all ${
        isMatched 
          ? 'border-green-300 bg-green-50' 
          : 'border-dashed border-gray-300 bg-white hover:border-purple-300 animate-pulse'
      }`}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      data-shapeid={shape.id}
    >
      {shape.image ? (
        <div 
          className={`w-20 h-20 rounded-lg overflow-hidden ${isMatched ? 'animate-matched' : 'opacity-20'}`}
          style={{
            backgroundImage: `url(${shape.image})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            filter: isMatched ? 'none' : 'grayscale(1)'
          }}
        />
      ) : (
        <div className={isMatched ? 'animate-matched' : 'opacity-20'}>
          <ShapeIcon 
            type={shape.type} 
            color={shape.color} 
            size={64} 
          />
        </div>
      )}
    </div>
  );
};

export default DropZone;