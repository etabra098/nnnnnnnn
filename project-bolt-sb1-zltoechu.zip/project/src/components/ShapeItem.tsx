import React from 'react';
import { Shape } from '../types';
import { ShapeIcon } from './ShapeIcon';

interface ShapeItemProps {
  shape: Shape;
  onDragStart: (shape: Shape) => void;
  onDragEnd: () => void;
  isActive: boolean;
}

const ShapeItem: React.FC<ShapeItemProps> = ({ 
  shape, 
  onDragStart, 
  onDragEnd, 
  isActive 
}) => {
  const handleDragStart = (e: React.DragEvent<HTMLDivElement>) => {
    e.dataTransfer.setData('text/plain', shape.id);
    e.dataTransfer.effectAllowed = 'move';
    onDragStart(shape);
  };

  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    onDragStart(shape);
  };

  const handleTouchEnd = () => {
    onDragEnd();
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    const touch = e.touches[0];
    const element = document.elementFromPoint(touch.clientX, touch.clientY) as HTMLElement;
    
    if (element?.dataset?.shapeid) {
      const dropzoneId = element.dataset.shapeid;
      if (dropzoneId === shape.id) {
        onDragEnd();
      }
    }
  };

  return (
    <div
      className={`w-24 h-24 flex items-center justify-center cursor-grab active:cursor-grabbing transition-transform ${
        isActive ? 'scale-110 opacity-50' : 'hover:scale-105'
      }`}
      draggable="true"
      onDragStart={handleDragStart}
      onDragEnd={onDragEnd}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      onTouchMove={handleTouchMove}
    >
      {shape.image ? (
        <div 
          className="w-20 h-20 rounded-lg overflow-hidden shadow-lg"
          style={{
            backgroundImage: `url(${shape.image})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        />
      ) : (
        <ShapeIcon 
          type={shape.type} 
          color={shape.color} 
          size={80} 
        />
      )}
    </div>
  );
};

export default ShapeItem;