import React from 'react';
import { 
  Square, 
  Circle, 
  Triangle,
  Pentagon,
  Hexagon,
  Star,
  Heart,
  Car,
  Truck,
  Bus,
  Plane,
  Ship,
  Train,
  Bike,
  type LucideProps
} from 'lucide-react';

type ShapeType = 
  | 'square' 
  | 'circle' 
  | 'triangle' 
  | 'rectangle' 
  | 'pentagon' 
  | 'hexagon' 
  | 'star' 
  | 'heart'
  | 'dog'
  | 'cat'
  | 'bird'
  | 'fish'
  | 'rabbit'
  | 'bear'
  | 'elephant'
  | 'giraffe'
  | 'car'
  | 'truck'
  | 'bus'
  | 'motorcycle'
  | 'train'
  | 'airplane'
  | 'ship'
  | 'helicopter';

interface ShapeIconProps {
  type: ShapeType;
  color: string;
  size: number;
}

export const ShapeIcon: React.FC<ShapeIconProps> = ({ type, color, size }) => {
  const iconProps: LucideProps = {
    size,
    color,
    strokeWidth: 2,
    fill: 'none'
  };

  const filledIconProps = {
    ...iconProps,
    fill: color,
    fillOpacity: 0.2
  };

  // Basic shapes with fill
  switch (type) {
    case 'square':
      return <Square {...filledIconProps} />;
    case 'circle':
      return <Circle {...filledIconProps} />;
    case 'triangle':
      return <Triangle {...filledIconProps} />;
    case 'rectangle':
      return <Square {...filledIconProps} width={size * 1.5} height={size} />;
    case 'pentagon':
      return <Pentagon {...filledIconProps} />;
    case 'hexagon':
      return <Hexagon {...filledIconProps} />;
    case 'star':
      return <Star {...filledIconProps} />;
    case 'heart':
      return <Heart {...filledIconProps} />;
    case 'car':
      return <Car {...filledIconProps} />;
    case 'truck':
      return <Truck {...filledIconProps} />;
    case 'bus':
      return <Bus {...filledIconProps} />;
    case 'motorcycle':
      return <Bike {...filledIconProps} />;
    case 'train':
      return <Train {...filledIconProps} />;
    case 'airplane':
      return <Plane {...filledIconProps} />;
    case 'ship':
      return <Ship {...filledIconProps} />;
    case 'helicopter':
      return <Plane {...filledIconProps} rotate={45} />;
    case 'dog':
      return (
        <div className="relative" style={{ width: size, height: size }}>
          <Circle {...filledIconProps} />
          <Triangle {...filledIconProps} style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -80%) rotate(180deg)', width: size * 0.6 }} />
        </div>
      );
    case 'cat':
      return (
        <div className="relative" style={{ width: size, height: size }}>
          <Circle {...filledIconProps} />
          <Triangle {...filledIconProps} style={{ position: 'absolute', top: 0, left: '50%', transform: 'translate(-50%, -30%) rotate(0deg)', width: size * 0.4 }} />
          <Triangle {...filledIconProps} style={{ position: 'absolute', top: 0, left: '20%', transform: 'translate(-50%, -30%) rotate(-30deg)', width: size * 0.4 }} />
          <Triangle {...filledIconProps} style={{ position: 'absolute', top: 0, right: '20%', transform: 'translate(50%, -30%) rotate(30deg)', width: size * 0.4 }} />
        </div>
      );
    case 'bird':
      return (
        <div className="relative" style={{ width: size, height: size }}>
          <Circle {...filledIconProps} />
          <Triangle {...filledIconProps} style={{ position: 'absolute', top: '50%', right: -size * 0.2, transform: 'translateY(-50%) rotate(-90deg)', width: size * 0.6 }} />
        </div>
      );
    case 'fish':
      return (
        <div className="relative" style={{ width: size, height: size }}>
          <Circle {...filledIconProps} />
          <Triangle {...filledIconProps} style={{ position: 'absolute', top: '50%', right: -size * 0.3, transform: 'translateY(-50%) rotate(-90deg)', width: size * 0.8 }} />
          <Triangle {...filledIconProps} style={{ position: 'absolute', top: '20%', right: -size * 0.1, transform: 'rotate(-45deg)', width: size * 0.4 }} />
          <Triangle {...filledIconProps} style={{ position: 'absolute', bottom: '20%', right: -size * 0.1, transform: 'rotate(45deg)', width: size * 0.4 }} />
        </div>
      );
    case 'rabbit':
      return (
        <div className="relative" style={{ width: size, height: size }}>
          <Circle {...filledIconProps} />
          <Triangle {...filledIconProps} style={{ position: 'absolute', top: -size * 0.3, left: '50%', transform: 'translateX(-50%) rotate(0deg)', width: size * 0.4 }} />
          <Triangle {...filledIconProps} style={{ position: 'absolute', top: -size * 0.3, left: '30%', transform: 'translateX(-50%) rotate(-15deg)', width: size * 0.4 }} />
        </div>
      );
    case 'bear':
      return (
        <div className="relative" style={{ width: size, height: size }}>
          <Circle {...filledIconProps} />
          <Circle {...filledIconProps} style={{ position: 'absolute', top: -size * 0.2, left: '20%', transform: 'scale(0.4)' }} />
          <Circle {...filledIconProps} style={{ position: 'absolute', top: -size * 0.2, right: '20%', transform: 'scale(0.4)' }} />
        </div>
      );
    case 'elephant':
      return (
        <div className="relative" style={{ width: size, height: size }}>
          <Circle {...filledIconProps} />
          <Rectangle {...filledIconProps} style={{ position: 'absolute', top: '50%', left: -size * 0.2, transform: 'translateY(-50%)', width: size * 0.8, height: size * 0.3 }} />
        </div>
      );
    case 'giraffe':
      return (
        <div className="relative" style={{ width: size, height: size }}>
          <Circle {...filledIconProps} />
          <Rectangle {...filledIconProps} style={{ position: 'absolute', bottom: '50%', left: '50%', transform: 'translateX(-50%)', width: size * 0.2, height: size * 0.8 }} />
        </div>
      );
    default:
      return <Circle {...filledIconProps} />;
  }
};