import React, { useEffect, useState } from 'react';
import Button from './ui/Button';
import { useGameState } from '../contexts/GameContext';
import { Star, Home, ChevronRight } from 'lucide-react';

interface LevelCompleteProps {
  level: number;
  onNext: () => void;
  onMenu: () => void;
}

const LevelComplete: React.FC<LevelCompleteProps> = ({ level, onNext, onMenu }) => {
  const { getStarsForLevel } = useGameState();
  const [stars, setStars] = useState(0);
  const [showConfetti, setShowConfetti] = useState(false);

  useEffect(() => {
    // Calculate stars based on level performance
    const starsCount = getStarsForLevel(level);
    
    // Animate stars appearance
    const timer = setTimeout(() => {
      setStars(starsCount);
      setShowConfetti(true);
    }, 500);
    
    return () => clearTimeout(timer);
  }, [level, getStarsForLevel]);

  // Function to render stars
  const renderStars = () => {
    return Array(3)
      .fill(0)
      .map((_, index) => (
        <Star
          key={index}
          size={40}
          className={`transition-all duration-500 ${
            index < stars
              ? 'text-yellow-400 fill-yellow-400 scale-110'
              : 'text-gray-300'
          }`}
        />
      ));
  };
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-10">
      <div className="bg-white rounded-xl shadow-2xl p-8 max-w-md w-full mx-4 transform transition-all">
        {showConfetti && (
          <div className="confetti-container absolute inset-0 overflow-hidden pointer-events-none">
            {/* Confetti particles would be added here with CSS animations */}
          </div>
        )}
        
        <h2 className="text-3xl font-bold text-center mb-2 text-purple-600">Level Complete!</h2>
        <p className="text-gray-600 text-center mb-6">
          Great job! You've completed level {level}.
        </p>
        
        <div className="flex justify-center gap-4 mb-8">
          {renderStars()}
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4">
          <Button
            onClick={onMenu}
            variant="outline"
            icon={<Home />}
            fullWidth
          >
            Level Menu
          </Button>
          
          {level < 15 && (
            <Button
              onClick={onNext}
              variant="primary"
              icon={<ChevronRight />}
              fullWidth
            >
              Next Level
            </Button>
          )}
        </div>
      </div>
    </div>
  );
};

export default LevelComplete;