import React, { useEffect } from 'react';
import { Puzzle as PuzzlePiece, PlayCircle, HelpCircle, Settings } from 'lucide-react';
import { GameScreen } from '../App';
import { useAudio } from '../contexts/AudioContext';
import Button from './ui/Button';

interface HomePageProps {
  navigateTo: (screen: GameScreen) => void;
}

const HomePage: React.FC<HomePageProps> = ({ navigateTo }) => {
  const { playBackgroundMusic } = useAudio();
  
  useEffect(() => {
    // Start background music when the home page loads
    playBackgroundMusic();
  }, [playBackgroundMusic]);

  return (
    <div className="flex flex-col items-center justify-center p-8 space-y-8 min-h-[600px]">
      <div className="flex items-center gap-3 text-4xl md:text-5xl font-bold text-purple-600 mb-4">
        <PuzzlePiece size={48} strokeWidth={2} className="text-purple-600" />
        <h1>Shape Match</h1>
      </div>
      
      <p className="text-center text-gray-600 text-lg max-w-md mb-8">
        A fun game for kids to learn shapes by matching them to their correct places!
      </p>
      
      <div className="flex flex-col space-y-4 w-full max-w-xs">
        <Button 
          onClick={() => navigateTo('levels')}
          variant="primary"
          icon={<PlayCircle />}
        >
          Start Game
        </Button>
        
        <Button 
          onClick={() => navigateTo('howToPlay')}
          variant="secondary"
          icon={<HelpCircle />}
        >
          How to Play
        </Button>
        
        <Button 
          onClick={() => navigateTo('settings')}
          variant="outline"
          icon={<Settings />}
        >
          Settings
        </Button>
      </div>
      
      <div className="absolute bottom-4 right-4">
        <p className="text-xs text-gray-400">v1.0.0</p>
      </div>
    </div>
  );
};

export default HomePage;