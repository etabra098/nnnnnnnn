import React from 'react';
import { ChevronLeft, MousePointer, Smartphone, Award } from 'lucide-react';
import { GameScreen } from '../App';
import Button from './ui/Button';

interface HowToPlayProps {
  navigateTo: (screen: GameScreen) => void;
}

const HowToPlay: React.FC<HowToPlayProps> = ({ navigateTo }) => {
  return (
    <div className="p-6 max-w-2xl mx-auto">
      <div className="flex items-center mb-6">
        <Button
          onClick={() => navigateTo('home')}
          variant="outline"
          size="sm"
          icon={<ChevronLeft size={18} />}
        >
          Back
        </Button>
        <h1 className="text-2xl font-bold text-center flex-1">How to Play</h1>
      </div>
      
      <div className="space-y-6">
        <div className="bg-blue-50 rounded-xl p-4 flex gap-4">
          <div className="flex-shrink-0 bg-blue-100 rounded-full p-3">
            <MousePointer size={24} className="text-blue-600" />
          </div>
          <div>
            <h3 className="font-bold text-lg mb-1">Mouse Controls</h3>
            <p className="text-gray-700">
              Click and drag a shape from the left container to its matching outline on the right. 
              Release the mouse button to drop the shape.
            </p>
          </div>
        </div>
        
        <div className="bg-purple-50 rounded-xl p-4 flex gap-4">
          <div className="flex-shrink-0 bg-purple-100 rounded-full p-3">
            <Smartphone size={24} className="text-purple-600" />
          </div>
          <div>
            <h3 className="font-bold text-lg mb-1">Touch Controls</h3>
            <p className="text-gray-700">
              Tap and hold on a shape, then drag your finger to move it. Release your finger when the shape is over its matching outline.
            </p>
          </div>
        </div>
        
        <div className="bg-green-50 rounded-xl p-4 flex gap-4">
          <div className="flex-shrink-0 bg-green-100 rounded-full p-3">
            <Award size={24} className="text-green-600" />
          </div>
          <div>
            <h3 className="font-bold text-lg mb-1">Game Progression</h3>
            <p className="text-gray-700">
              Match all shapes to complete a level. Each level gets progressively harder with more shapes to match. Completing levels unlocks new ones!
            </p>
          </div>
        </div>
        
        <div className="border-t pt-4 mt-4">
          <h3 className="font-bold text-lg mb-2">Tips:</h3>
          <ul className="list-disc list-inside space-y-2 text-gray-700">
            <li>Look carefully at the shape's outline before dragging</li>
            <li>Focus on one shape at a time</li>
            <li>Try to remember which shape goes where</li>
            <li>You can use the reset button if you get stuck</li>
            <li>Have fun and don't rush!</li>
          </ul>
        </div>
      </div>
      
      <div className="flex justify-center mt-8">
        <Button
          onClick={() => navigateTo('levels')}
          variant="primary"
        >
          Start Playing
        </Button>
      </div>
    </div>
  );
};

export default HowToPlay;