import { Shape } from '../types';

interface LevelTheme {
  name: string;
  color: string;
}

export const getLevelTheme = (level: number): LevelTheme => {
  // Basic shapes (levels 1-5)
  if (level >= 1 && level <= 5) {
    return {
      name: 'Basic Shapes',
      color: 'blue',
    };
  }
  
  // Animal shapes (levels 6-10)
  if (level >= 6 && level <= 10) {
    return {
      name: 'Animal Shapes',
      color: 'purple',
    };
  }
  
  // Vehicle shapes (levels 11-15)
  if (level >= 11 && level <= 15) {
    return {
      name: 'Vehicle Shapes',
      color: 'green',
    };
  }
  
  // Default fallback
  return {
    name: 'Shapes',
    color: 'gray',
  };
};

export const getNextLevel = (currentLevel: number): number | null => {
  if (currentLevel < 15) {
    return currentLevel + 1;
  }
  return null; // No more levels
};