import React, { useState } from 'react';
import GameProvider from './contexts/GameContext';
import HomePage from './components/HomePage';
import LevelSelector from './components/LevelSelector';
import GameArea from './components/GameArea';
import HowToPlay from './components/HowToPlay';
import Settings from './components/Settings';
import { AudioProvider } from './contexts/AudioContext';

export type GameScreen = 'home' | 'levels' | 'game' | 'howToPlay' | 'settings';

function App() {
  const [currentScreen, setCurrentScreen] = useState<GameScreen>('home');
  const [currentLevel, setCurrentLevel] = useState<number>(1);

  const navigateTo = (screen: GameScreen) => {
    setCurrentScreen(screen);
  };

  const startLevel = (level: number) => {
    setCurrentLevel(level);
    setCurrentScreen('game');
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'home':
        return <HomePage navigateTo={navigateTo} />;
      case 'levels':
        return <LevelSelector navigateTo={navigateTo} startLevel={startLevel} />;
      case 'game':
        return <GameArea level={currentLevel} navigateTo={navigateTo} />;
      case 'howToPlay':
        return <HowToPlay navigateTo={navigateTo} />;
      case 'settings':
        return <Settings navigateTo={navigateTo} />;
      default:
        return <HomePage navigateTo={navigateTo} />;
    }
  };

  return (
    <AudioProvider>
      <GameProvider>
        <div className="min-h-screen bg-gradient-to-b from-blue-100 to-purple-100 flex items-center justify-center p-4">
          <div className="w-full max-w-4xl bg-white rounded-2xl shadow-xl overflow-hidden">
            {renderScreen()}
          </div>
        </div>
      </GameProvider>
    </AudioProvider>
  );
}

export default App;