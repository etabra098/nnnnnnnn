import { useState, useCallback } from 'react';
import { Shape } from '../types';
import { useGameState } from '../contexts/GameContext';

interface DragAndDropHookProps {
  onCorrectMatch: (shapeId: string) => void;
  onIncorrectMatch: () => void;
}

export const useDragAndDrop = ({ onCorrectMatch, onIncorrectMatch }: DragAndDropHookProps) => {
  const [activeShape, setActiveShape] = useState<Shape | null>(null);
  const { gameSpeed } = useGameState();
  
  const handleDragStart = useCallback((shape: Shape) => {
    setActiveShape(shape);
  }, []);
  
  const handleDragEnd = useCallback(() => {
    setActiveShape(null);
  }, []);
  
  const handleDrop = useCallback(
    (dropZoneId: string) => {
      if (!activeShape) return;
      
      // Check if the shape matches the drop zone
      const isMatch = activeShape.id === dropZoneId;
      
      if (isMatch) {
        // Apply game speed to adjust timing
        setTimeout(() => {
          onCorrectMatch(activeShape.id);
        }, 300 / gameSpeed);
      } else {
        // Incorrect match
        onIncorrectMatch();
        
        // Apply the shake animation to the dropped element
        const dropZoneElement = document.querySelector(`[data-shapeid="${dropZoneId}"]`);
        if (dropZoneElement) {
          dropZoneElement.classList.add('shake-animation');
          
          // Remove the class after the animation completes
          setTimeout(() => {
            dropZoneElement.classList.remove('shake-animation');
          }, 500 / gameSpeed);
        }
      }
      
      // Clear the active shape
      setActiveShape(null);
    },
    [activeShape, onCorrectMatch, onIncorrectMatch, gameSpeed]
  );
  
  return {
    activeShape,
    handleDragStart,
    handleDragEnd,
    handleDrop,
  };
};