import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface GameState {
  completedLevels: number[];
  highContrastMode: boolean;
  gameSpeed: number;
}

interface GameContextType {
  completedLevels: number[];
  completeLevel: (level: number) => void;
  highContrastMode: boolean;
  toggleHighContrastMode: () => void;
  gameSpeed: number;
  setGameSpeed: (speed: number) => void;
  getStarsForLevel: (level: number) => number;
  resetProgress: () => void;
}

const GameContext = createContext<GameContextType | undefined>(undefined);

const initialState: GameState = {
  completedLevels: [],
  highContrastMode: false,
  gameSpeed: 1,
};

interface GameProviderProps {
  children: ReactNode;
}

const GameProvider: React.FC<GameProviderProps> = ({ children }) => {
  const [state, setState] = useState<GameState>(() => {
    const savedState = localStorage.getItem('shapeMatchGameState');
    return savedState ? JSON.parse(savedState) : initialState;
  });

  useEffect(() => {
    localStorage.setItem('shapeMatchGameState', JSON.stringify(state));
  }, [state]);

  const completeLevel = (level: number) => {
    setState((prev) => {
      // Only add the level if it's not already in the array
      if (!prev.completedLevels.includes(level)) {
        return {
          ...prev,
          completedLevels: [...prev.completedLevels, level],
        };
      }
      return prev;
    });
  };

  const toggleHighContrastMode = () => {
    setState((prev) => ({
      ...prev,
      highContrastMode: !prev.highContrastMode,
    }));
  };

  const setGameSpeed = (speed: number) => {
    setState((prev) => ({
      ...prev,
      gameSpeed: speed,
    }));
  };

  const getStarsForLevel = (level: number) => {
    // For now, simply return a random number of stars (1-3)
    // In a real implementation, this would be based on time, moves, etc.
    return Math.floor(Math.random() * 3) + 1;
  };

  const resetProgress = () => {
    setState(initialState);
    localStorage.removeItem('shapeMatchGameState');
  };

  return (
    <GameContext.Provider
      value={{
        completedLevels: state.completedLevels,
        completeLevel,
        highContrastMode: state.highContrastMode,
        toggleHighContrastMode,
        gameSpeed: state.gameSpeed,
        setGameSpeed,
        getStarsForLevel,
        resetProgress,
      }}
    >
      {children}
    </GameContext.Provider>
  );
};

export const useGameState = (): GameContextType => {
  const context = useContext(GameContext);
  if (context === undefined) {
    throw new Error('useGameState must be used within a GameProvider');
  }
  return context;
};

export default GameProvider;