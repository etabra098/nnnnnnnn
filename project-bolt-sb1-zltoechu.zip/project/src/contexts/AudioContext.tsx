import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { Howl } from 'howler';

interface AudioContextType {
  volume: number;
  setVolume: (volume: number) => void;
  isMuted: boolean;
  toggleMute: () => void;
  playMatchSound: () => void;
  playErrorSound: () => void;
  playLevelCompleteSound: () => void;
  playBackgroundMusic: () => void;
  stopBackgroundMusic: () => void;
  playPopSound: () => void;
  playStarSound: () => void;
}

const AudioContext = createContext<AudioContextType | undefined>(undefined);

// Sound effects using Howler.js
const sounds = {
  match: new Howl({
    src: ['https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3'],
    volume: 0.5,
  }),
  error: new Howl({
    src: ['https://assets.mixkit.co/active_storage/sfx/2572/2572-preview.mp3'],
    volume: 0.3,
  }),
  levelComplete: new Howl({
    src: ['https://assets.mixkit.co/active_storage/sfx/2573/2573-preview.mp3'],
    volume: 0.7,
  }),
  background: new Howl({
    src: ['https://assets.mixkit.co/active_storage/sfx/2574/2574-preview.mp3'],
    volume: 0.2,
    loop: true,
  }),
  pop: new Howl({
    src: ['https://assets.mixkit.co/active_storage/sfx/2575/2575-preview.mp3'],
    volume: 0.3,
  }),
  star: new Howl({
    src: ['https://assets.mixkit.co/active_storage/sfx/2576/2576-preview.mp3'],
    volume: 0.5,
  }),
};

interface AudioProviderProps {
  children: ReactNode;
}

export const AudioProvider: React.FC<AudioProviderProps> = ({ children }) => {
  const [volume, setVolume] = useState(() => {
    const savedVolume = localStorage.getItem('shapeMatchVolume');
    return savedVolume ? parseInt(savedVolume, 10) : 50;
  });
  
  const [isMuted, setIsMuted] = useState(() => {
    const savedMuted = localStorage.getItem('shapeMatchMuted');
    return savedMuted ? savedMuted === 'true' : false;
  });

  useEffect(() => {
    localStorage.setItem('shapeMatchVolume', volume.toString());
    localStorage.setItem('shapeMatchMuted', isMuted.toString());
    
    // Update all sound volumes
    Object.values(sounds).forEach(sound => {
      sound.volume(isMuted ? 0 : volume / 100);
    });
  }, [volume, isMuted]);

  const toggleMute = useCallback(() => {
    setIsMuted(prev => !prev);
  }, []);

  const playSound = useCallback((sound: Howl) => {
    if (!isMuted) {
      sound.play();
    }
  }, [isMuted]);

  const playMatchSound = useCallback(() => {
    playSound(sounds.match);
  }, [playSound]);

  const playErrorSound = useCallback(() => {
    playSound(sounds.error);
  }, [playSound]);

  const playLevelCompleteSound = useCallback(() => {
    playSound(sounds.levelComplete);
  }, [playSound]);

  const playPopSound = useCallback(() => {
    playSound(sounds.pop);
  }, [playSound]);

  const playStarSound = useCallback(() => {
    playSound(sounds.star);
  }, [playSound]);

  const playBackgroundMusic = useCallback(() => {
    if (!isMuted) {
      sounds.background.play();
    }
  }, [isMuted]);

  const stopBackgroundMusic = useCallback(() => {
    sounds.background.stop();
  }, []);

  useEffect(() => {
    return () => {
      Object.values(sounds).forEach(sound => sound.unload());
    };
  }, []);

  return (
    <AudioContext.Provider
      value={{
        volume,
        setVolume,
        isMuted,
        toggleMute,
        playMatchSound,
        playErrorSound,
        playLevelCompleteSound,
        playBackgroundMusic,
        stopBackgroundMusic,
        playPopSound,
        playStarSound,
      }}
    >
      {children}
    </AudioContext.Provider>
  );
};

export const useAudio = (): AudioContextType => {
  const context = useContext(AudioContext);
  if (context === undefined) {
    throw new Error('useAudio must be used within an AudioProvider');
  }
  return context;
};