export type ShapeType = 
  | 'square' 
  | 'circle' 
  | 'triangle' 
  | 'rectangle' 
  | 'pentagon' 
  | 'hexagon' 
  | 'star' 
  | 'heart'
  | 'dog'
  | 'cat'
  | 'bird'
  | 'fish'
  | 'rabbit'
  | 'bear'
  | 'elephant'
  | 'giraffe'
  | 'car'
  | 'truck'
  | 'bus'
  | 'motorcycle'
  | 'train'
  | 'airplane'
  | 'ship'
  | 'helicopter'
  | 'fruit'
  | 'number'
  | 'letter';

export interface Shape {
  id: string;
  type: ShapeType;
  color: string;
  image?: string;
}