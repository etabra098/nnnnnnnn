import { Shape } from '../types';

interface LevelData {
  id: number;
  title: string;
  shapes: Shape[];
  category: 'basic' | 'animal' | 'vehicle' | 'fruit' | 'number' | 'letter';
}

// Basic Shape Levels (1-5)
const basicShapeLevels: LevelData[] = [
  {
    id: 1,
    title: 'Basic Shapes I',
    category: 'basic',
    shapes: [
      { id: 'square', type: 'square', color: '#3B82F6' },
      { id: 'circle', type: 'circle', color: '#EC4899' },
    ],
  },
  // ... (previous basic shapes levels remain the same)
];

// Animal Shape Levels (6-10)
const animalShapeLevels: LevelData[] = [
  // ... (previous animal levels remain the same)
];

// Vehicle Shape Levels (11-15)
const vehicleShapeLevels: LevelData[] = [
  // ... (previous vehicle levels remain the same)
];

// Fruit Shape Levels (16-20)
const fruitLevels: LevelData[] = [
  {
    id: 16,
    title: 'Fruits I',
    category: 'fruit',
    shapes: [
      { id: 'apple', type: 'fruit', color: '#EF4444', image: 'https://images.pexels.com/photos/102104/pexels-photo-102104.jpeg' },
      { id: 'banana', type: 'fruit', color: '#F59E0B', image: 'https://images.pexels.com/photos/1093038/pexels-photo-1093038.jpeg' },
    ],
  },
  {
    id: 17,
    title: 'Fruits II',
    category: 'fruit',
    shapes: [
      { id: 'orange', type: 'fruit', color: '#F97316', image: 'https://images.pexels.com/photos/327098/pexels-photo-327098.jpeg' },
      { id: 'strawberry', type: 'fruit', color: '#DC2626', image: 'https://images.pexels.com/photos/46174/strawberries-berries-fruit-freshness-46174.jpeg' },
      { id: 'grape', type: 'fruit', color: '#7C3AED', image: 'https://images.pexels.com/photos/708777/pexels-photo-708777.jpeg' },
    ],
  },
  {
    id: 18,
    title: 'Fruits III',
    category: 'fruit',
    shapes: [
      { id: 'watermelon', type: 'fruit', color: '#059669', image: 'https://images.pexels.com/photos/5946081/pexels-photo-5946081.jpeg' },
      { id: 'pineapple', type: 'fruit', color: '#F59E0B', image: 'https://images.pexels.com/photos/947879/pexels-photo-947879.jpeg' },
      { id: 'mango', type: 'fruit', color: '#F97316', image: 'https://images.pexels.com/photos/918643/pexels-photo-918643.jpeg' },
      { id: 'kiwi', type: 'fruit', color: '#65A30D', image: 'https://images.pexels.com/photos/51312/kiwi-fruit-vitamins-healthy-sweet-51312.jpeg' },
    ],
  },
  {
    id: 19,
    title: 'Fruits IV',
    category: 'fruit',
    shapes: [
      { id: 'peach', type: 'fruit', color: '#FB923C', image: 'https://images.pexels.com/photos/1268122/pexels-photo-1268122.jpeg' },
      { id: 'pear', type: 'fruit', color: '#65A30D', image: 'https://images.pexels.com/photos/568471/pexels-photo-568471.jpeg' },
      { id: 'plum', type: 'fruit', color: '#7C3AED', image: 'https://images.pexels.com/photos/248440/pexels-photo-248440.jpeg' },
      { id: 'cherry', type: 'fruit', color: '#DC2626', image: 'https://images.pexels.com/photos/109274/pexels-photo-109274.jpeg' },
      { id: 'lemon', type: 'fruit', color: '#F59E0B', image: 'https://images.pexels.com/photos/952360/pexels-photo-952360.jpeg' },
    ],
  },
  {
    id: 20,
    title: 'Fruits Mix',
    category: 'fruit',
    shapes: [
      { id: 'apple', type: 'fruit', color: '#EF4444', image: 'https://images.pexels.com/photos/102104/pexels-photo-102104.jpeg' },
      { id: 'banana', type: 'fruit', color: '#F59E0B', image: 'https://images.pexels.com/photos/1093038/pexels-photo-1093038.jpeg' },
      { id: 'orange', type: 'fruit', color: '#F97316', image: 'https://images.pexels.com/photos/327098/pexels-photo-327098.jpeg' },
      { id: 'strawberry', type: 'fruit', color: '#DC2626', image: 'https://images.pexels.com/photos/46174/strawberries-berries-fruit-freshness-46174.jpeg' },
      { id: 'grape', type: 'fruit', color: '#7C3AED', image: 'https://images.pexels.com/photos/708777/pexels-photo-708777.jpeg' },
      { id: 'watermelon', type: 'fruit', color: '#059669', image: 'https://images.pexels.com/photos/5946081/pexels-photo-5946081.jpeg' },
    ],
  },
];

// Number Levels (21-25)
const numberLevels: LevelData[] = [
  {
    id: 21,
    title: 'Numbers I',
    category: 'number',
    shapes: [
      { id: 'one', type: 'number', color: '#3B82F6', image: 'https://images.pexels.com/photos/5039400/pexels-photo-5039400.jpeg' },
      { id: 'two', type: 'number', color: '#EC4899', image: 'https://images.pexels.com/photos/5039401/pexels-photo-5039401.jpeg' },
    ],
  },
  // ... Add more number levels
];

// Letter Levels (26-30)
const letterLevels: LevelData[] = [
  {
    id: 26,
    title: 'Letters I',
    category: 'letter',
    shapes: [
      { id: 'a', type: 'letter', color: '#3B82F6', image: 'https://images.pexels.com/photos/5039402/pexels-photo-5039402.jpeg' },
      { id: 'b', type: 'letter', color: '#EC4899', image: 'https://images.pexels.com/photos/5039403/pexels-photo-5039403.jpeg' },
    ],
  },
  // ... Add more letter levels
];

// Combine all levels
const allLevels: LevelData[] = [
  ...basicShapeLevels,
  ...animalShapeLevels,
  ...vehicleShapeLevels,
  ...fruitLevels,
  ...numberLevels,
  ...letterLevels,
];

export const getLevelData = (levelId: number): LevelData => {
  const level = allLevels.find((l) => l.id === levelId);
  if (!level) {
    throw new Error(`Level with ID ${levelId} not found`);
  }
  return level;
};

export const getLevelsByCategory = (category: LevelData['category']) => {
  return allLevels.filter(level => level.category === category);
};